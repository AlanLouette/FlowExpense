<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/lib/markdown.php';
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];
$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

$categoriesStmt = $db->prepare('SELECT id, name FROM expense_categories WHERE organization_id = ? ORDER BY name ASC');
$categoriesStmt->execute([$orgId]);
$categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

$recipientsStmt = $db->prepare('SELECT DISTINCT recipient FROM expense_reports WHERE organization_id = ? ORDER BY recipient ASC');
$recipientsStmt->execute([$orgId]);
$recipients = $recipientsStmt->fetchAll(PDO::FETCH_COLUMN);

$selectedCategoryId = $_GET['category_id'] ?? '';
$selectedRecipient = $_GET['recipient'] ?? '';
$selectedStatus = $_GET['status'] ?? '';
$sort = $_GET['sort'] ?? 'date';
$order = strtoupper($_GET['order'] ?? 'DESC');

$allowedSort = ['custom_id', 'recipient', 'date', 'total', 'status'];
if (!in_array($sort, $allowedSort, true)) {
    $sort = 'date';
}
if (!in_array($order, ['ASC', 'DESC'], true)) {
    $order = 'DESC';
}

$where = ['organization_id = ?'];
$params = [$orgId];
if (!$isAdmin) {
    $where[] = 'user_id = ?';
    $params[] = (int)$currentUser['id'];
}
if ($selectedCategoryId !== '') {
    $where[] = 'category_id = ?';
    $params[] = (int)$selectedCategoryId;
}
if ($selectedRecipient !== '') {
    $where[] = 'recipient = ?';
    $params[] = $selectedRecipient;
}
if ($selectedStatus !== '') {
    $where[] = 'status = ?';
    $params[] = $selectedStatus;
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$query = "SELECT * FROM expense_reports $whereSql ORDER BY $sort $order";
$stmt = $db->prepare($query);
$stmt->execute($params);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

$attCounts = [];
if ($reports) {
    $ids = array_column($reports, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $attStmt = $db->prepare("SELECT report_id, COUNT(*) as cnt FROM expense_attachments WHERE report_id IN ($placeholders) GROUP BY report_id");
    $attStmt->execute($ids);
    foreach ($attStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $attCounts[(int)$row['report_id']] = (int)$row['cnt'];
    }
}

$totalAmount = 0.0;
$totalOpen = 0.0;
foreach ($reports as $report) {
    $totalAmount += (float)($report['total'] ?? 0);
    if (($report['status'] ?? 'Open') === 'Open') {
        $totalOpen += (float)($report['total'] ?? 0);
    }
}

renderPageStart('Dashboard', 'index');
?>
<section class="card">
    <div class="grid-2" style="gap:24px;">
        <div>
            <h2>Overzicht</h2>
            <p class="notice" style="margin-top:12px;">Je bekijkt de onkostennota's voor <strong><?= htmlspecialchars($currentOrganization['name']) ?></strong>. Alle bedragen zijn exclusief BTW.</p>
        </div>
        <div class="grid-2" style="gap:16px;">
            <div class="card" style="margin:0;">
                <div class="badge">Totaal bedrag</div>
                <div style="font-size:1.8rem;font-weight:600;margin-top:8px;">€ <?= number_format($totalAmount, 2, ',', '.') ?></div>
            </div>
            <div class="card" style="margin:0;">
                <div class="badge">Openstaand</div>
                <div style="font-size:1.8rem;font-weight:600;margin-top:8px;">€ <?= number_format($totalOpen, 2, ',', '.') ?></div>
            </div>
        </div>
    </div>
</section>

<section class="card" style="margin-top:24px;">
    <form class="grid-2" method="get" id="filterForm" style="margin:0;box-shadow:none;background:transparent;padding:0;">
        <label>Categorie
            <select name="category_id" onchange="this.form.submit()">
                <option value="">Alle categorieën</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= (int)$cat['id'] ?>" <?= ((string)$selectedCategoryId === (string)$cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Ontvanger
            <select name="recipient" onchange="this.form.submit()">
                <option value="">Alle ontvangers</option>
                <?php foreach ($recipients as $recipientName): ?>
                    <option value="<?= htmlspecialchars($recipientName) ?>" <?= ($selectedRecipient === $recipientName) ? 'selected' : '' ?>><?= htmlspecialchars($recipientName) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Status
            <select name="status" onchange="this.form.submit()">
                <option value="">Alle statussen</option>
                <option value="Open" <?= $selectedStatus === 'Open' ? 'selected' : '' ?>>Open</option>
                <option value="Complete" <?= $selectedStatus === 'Complete' ? 'selected' : '' ?>>Complete</option>
                <option value="Paid" <?= $selectedStatus === 'Paid' ? 'selected' : '' ?>>Paid</option>
            </select>
        </label>
        <div class="bulk-toolbar">
            <button type="button" class="button" onclick="window.location.href='index.php'">Reset filters</button>
        </div>
        <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">
        <input type="hidden" name="order" value="<?= htmlspecialchars($order) ?>">
    </form>
</section>

<div class="bulk-toolbar">
    <div><input type="checkbox" id="select-all"> <label for="select-all">Selecteer alles</label></div>
    <button type="button" id="bulk-export" disabled>Exporteer selectie (PDF)</button>
    <button type="button" id="bulk-delete" disabled class="button" style="background:linear-gradient(135deg,#ef4444,#dc2626);">Verwijder selectie</button>
    <span id="selection-count" class="badge" style="display:none;"></span>
</div>

<?php if (empty($reports)): ?>
    <div class="notice">Er zijn geen onkostennota's gevonden met de huidige filters.</div>
<?php else: ?>
    <table class="index-table">
        <thead>
        <tr>
            <th><input type="checkbox" id="select-all-head"></th>
            <th><a href="<?= sortUrl('custom_id', $sort, $order, $selectedCategoryId, $selectedRecipient, $selectedStatus) ?>">Nummer</a></th>
            <th><a href="<?= sortUrl('recipient', $sort, $order, $selectedCategoryId, $selectedRecipient, $selectedStatus) ?>">Ontvanger</a></th>
            <th>Omschrijving</th>
            <th><a href="<?= sortUrl('date', $sort, $order, $selectedCategoryId, $selectedRecipient, $selectedStatus) ?>">Datum</a></th>
            <th><a href="<?= sortUrl('total', $sort, $order, $selectedCategoryId, $selectedRecipient, $selectedStatus) ?>">Totaal</a></th>
            <th><a href="<?= sortUrl('status', $sort, $order, $selectedCategoryId, $selectedRecipient, $selectedStatus) ?>">Status</a></th>
            <th>Bijlagen</th>
            <th>Acties</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($reports as $report): ?>
            <?php
            $desc = $report['description'] ?? '';
            $rendered = markdown_to_html($desc);
            $snippet = strip_tags($rendered);
            if (strlen($snippet) > 160) {
                $snippet = mb_substr($snippet, 0, 160) . '…';
            }
            $status = $report['status'] ?? 'Open';
            $attCnt = $attCounts[(int)$report['id']] ?? 0;
            ?>
            <tr data-id="<?= (int)$report['id'] ?>">
                <td><input type="checkbox" class="row-select" value="<?= (int)$report['id'] ?>"></td>
                <td><?= htmlspecialchars($report['custom_id'] ?: ('#' . $report['id'])) ?></td>
                <td><?= htmlspecialchars($report['recipient'] ?? '') ?></td>
                <td>
                    <div style="max-width:320px;">
                        <strong><?= htmlspecialchars($report['description'] ? strtok($report['description'], "\n") : 'Geen omschrijving') ?></strong>
                        <div style="font-size:0.85rem;color:var(--color-muted);margin-top:4px;">
                            <?= htmlspecialchars($snippet) ?>
                        </div>
                    </div>
                </td>
                <td><?= htmlspecialchars($report['date'] ?? '') ?></td>
                <td>€ <?= number_format((float)$report['total'], 2, ',', '.') ?></td>
                <td>
                    <select class="status-select" data-id="<?= (int)$report['id'] ?>">
                        <option value="Open" <?= $status === 'Open' ? 'selected' : '' ?>>Open</option>
                        <option value="Complete" <?= $status === 'Complete' ? 'selected' : '' ?>>Complete</option>
                        <option value="Paid" <?= $status === 'Paid' ? 'selected' : '' ?>>Paid</option>
                    </select>
                </td>
                <td><span class="badge">📎 <?= $attCnt ?></span></td>
                <td class="table-actions">
                    <a href="form.php?id=<?= (int)$report['id'] ?>">Bewerken</a>
                    <a href="export.php?id=<?= (int)$report['id'] ?>" target="_blank" rel="noopener">PDF</a>
                    <a href="export-xlsx.php?id=<?= (int)$report['id'] ?>">Excel</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<script>
const rowCheckboxes = Array.from(document.querySelectorAll('.row-select'));
const selectAll = document.getElementById('select-all');
const selectAllHead = document.getElementById('select-all-head');
const selectionCount = document.getElementById('selection-count');
const bulkExport = document.getElementById('bulk-export');
const bulkDelete = document.getElementById('bulk-delete');

function updateSelectionState() {
    const selected = rowCheckboxes.filter(cb => cb.checked).map(cb => cb.value);
    const hasSelection = selected.length > 0;
    bulkExport.disabled = !hasSelection;
    bulkDelete.disabled = !hasSelection;
    if (hasSelection) {
        selectionCount.textContent = selected.length + ' geselecteerd';
        selectionCount.style.display = 'inline-flex';
    } else {
        selectionCount.style.display = 'none';
    }
    if (selectAll) {
        selectAll.checked = selected.length === rowCheckboxes.length && rowCheckboxes.length > 0;
    }
    if (selectAllHead) {
        selectAllHead.checked = selectAll.checked;
    }
}

function gatherSelection() {
    return rowCheckboxes.filter(cb => cb.checked).map(cb => cb.value);
}

function toggleAll(checked) {
    rowCheckboxes.forEach(cb => cb.checked = checked);
    updateSelectionState();
}

rowCheckboxes.forEach(cb => cb.addEventListener('change', updateSelectionState));
if (selectAll) {
    selectAll.addEventListener('change', (e) => toggleAll(e.target.checked));
}
if (selectAllHead) {
    selectAllHead.addEventListener('change', (e) => toggleAll(e.target.checked));
}

async function handleBulkExport() {
    const ids = gatherSelection();
    if (!ids.length) return;
    const res = await fetch('bulk-export.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
    });
    if (!res.ok) {
        const text = await res.text();
        alert('Export mislukt: ' + text);
        return;
    }
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    const disposition = res.headers.get('Content-Disposition');
    let filename = 'onkostennotas.zip';
    if (disposition) {
        const match = /filename="?([^";]+)"?/i.exec(disposition);
        if (match) filename = match[1];
    }
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
}

async function handleBulkDelete() {
    const ids = gatherSelection();
    if (!ids.length) return;
    if (!confirm('Weet je zeker dat je deze onkostennota\'s wil verwijderen? Dit kan niet ongedaan gemaakt worden.')) {
        return;
    }
    const res = await fetch('bulk-delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
    });
    if (!res.ok) {
        const text = await res.text();
        alert('Verwijderen mislukt: ' + text);
        return;
    }
    const { removed } = await res.json();
    rowCheckboxes.forEach(cb => {
        if (removed.includes(parseInt(cb.value, 10))) {
            const row = cb.closest('tr');
            if (row) row.remove();
        }
    });
    updateSelectionState();
}

if (bulkExport) {
    bulkExport.addEventListener('click', handleBulkExport);
}
if (bulkDelete) {
    bulkDelete.addEventListener('click', handleBulkDelete);
}

async function updateStatus(id, status) {
    const res = await fetch('update-status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status })
    });
    if (!res.ok) {
        const text = await res.text();
        alert('Status bijwerken mislukt: ' + text);
    }
}

document.querySelectorAll('.status-select').forEach(select => {
    select.addEventListener('change', (event) => {
        const id = event.target.getAttribute('data-id');
        updateStatus(id, event.target.value);
    });
});

updateSelectionState();
</script>
<?php
renderPageEnd();

function sortUrl(string $column, string $currentSort, string $currentOrder, string $category, string $recipient, string $status): string
{
    $params = [
        'sort' => $column,
        'order' => ($currentSort === $column && $currentOrder === 'ASC') ? 'DESC' : 'ASC'
    ];
    if ($category !== '') $params['category_id'] = $category;
    if ($recipient !== '') $params['recipient'] = $recipient;
    if ($status !== '') $params['status'] = $status;
    return 'index.php?' . http_build_query($params);
}
