<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$redirect = $_POST['redirect'] ?? 'index.php';

if ($id <= 0) {
    http_response_code(400);
    exit('Ongeldig ID.');
}

$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

try {
    $stmt = $db->prepare('SELECT user_id FROM expense_reports WHERE id = ? AND organization_id = ?');
    $stmt->execute([$id, (int)$currentOrganization['id']]);
    $report = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$report) {
        http_response_code(404);
        exit('Onkostennota niet gevonden.');
    }
    if (!$isAdmin && (int)$report['user_id'] !== (int)$currentUser['id']) {
        http_response_code(403);
        exit('Geen toegang tot deze onkostennota.');
    }

    $attStmt = $db->prepare('SELECT stored_name FROM expense_attachments WHERE report_id = ?');
    $attStmt->execute([$id]);
    foreach ($attStmt->fetchAll(PDO::FETCH_ASSOC) as $attachment) {
        $path = '/var/www/data/attachments/' . $attachment['stored_name'];
        if (is_file($path)) {
            @unlink($path);
        }
    }

    $delete = $db->prepare('DELETE FROM expense_reports WHERE id = ?');
    $delete->execute([$id]);

    header('Location: ' . $redirect);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo 'Verwijderen mislukt: ' . htmlspecialchars($e->getMessage());
}
