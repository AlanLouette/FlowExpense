<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload) || empty($payload['ids']) || !is_array($payload['ids'])) {
    http_response_code(400);
    exit('Ongeldige selectie.');
}

$ids = array_unique(array_map('intval', $payload['ids']));
$ids = array_filter($ids, fn($id) => $id > 0);
if (empty($ids)) {
    http_response_code(400);
    exit('Geen geldige onkostennota IDs.');
}

$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;
$orgId = (int)$currentOrganization['id'];

$removed = [];

$selectStmt = $db->prepare('SELECT id, user_id FROM expense_reports WHERE id = ? AND organization_id = ?');
$deleteStmt = $db->prepare('DELETE FROM expense_reports WHERE id = ?');
$attStmt = $db->prepare('SELECT stored_name FROM expense_attachments WHERE report_id = ?');

foreach ($ids as $id) {
    $selectStmt->execute([$id, $orgId]);
    $report = $selectStmt->fetch(PDO::FETCH_ASSOC);
    if (!$report) {
        continue;
    }
    if (!$isAdmin && (int)$report['user_id'] !== (int)$currentUser['id']) {
        continue;
    }
    $attStmt->execute([$id]);
    foreach ($attStmt->fetchAll(PDO::FETCH_ASSOC) as $attachment) {
        $path = '/var/www/data/attachments/' . $attachment['stored_name'];
        if (is_file($path)) {
            @unlink($path);
        }
    }

    $deleteStmt->execute([$id]);
    $removed[] = $id;
}

header('Content-Type: application/json');
echo json_encode(['removed' => $removed]);
