<?php
require_once __DIR__ . '/markdown.php';

function expense_pdf_html(array $report, array $lines, array $organization): string
{
    $total = (float)($report['total'] ?? 0);
    $description = $report['description'] ?? '';
    $renderedDescription = markdown_to_html($description);
    $orgAddressParts = array_filter([
        $organization['address_line1'] ?? '',
        $organization['address_line2'] ?? '',
        trim(($organization['postal_code'] ?? '') . ' ' . ($organization['city'] ?? '')),
        $organization['country'] ?? ''
    ]);
    $orgAddress = implode("\n", $orgAddressParts);
    $brandAccent = $organization['branding_accent'] ?? '#3b82f6';

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <style>
            @page { margin: 32px; }
            body { font-family: 'DejaVu Sans', sans-serif; color: #1f2937; font-size: 12px; }
            .header { display: flex; justify-content: space-between; align-items: flex-start; }
            .brand { color: <?= htmlspecialchars($brandAccent) ?>; font-size: 28px; font-weight: 700; letter-spacing: 1px; }
            .meta { text-align: right; }
            .meta strong { display: block; font-size: 14px; }
            .section { margin-top: 24px; }
            h1 { font-size: 24px; margin: 0 0 6px; }
            h2 { font-size: 18px; margin: 0 0 12px; }
            h3 { font-size: 14px; margin: 18px 0 6px; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; }
            .info-grid { display: flex; gap: 20px; }
            .info-card { flex: 1; padding: 16px; border-radius: 12px; background: #f5f8ff; border: 1px solid #dbeafe; }
            .info-card strong { display: block; font-size: 12px; color: #6b7280; text-transform: uppercase; }
            .info-card span { display: block; font-size: 14px; margin-top: 6px; color: #1f2937; }
            table { width: 100%; border-collapse: collapse; margin-top: 16px; }
            th { background: #f1f5f9; text-align: left; padding: 10px; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: #64748b; }
            td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 12px; }
            tbody tr:nth-child(even) { background: #f8fafc; }
            .totals { margin-top: 16px; display: flex; justify-content: flex-end; }
            .totals table { width: 240px; }
            .totals td { border: none; padding: 6px 0; }
            .totals tr:last-child td { font-weight: 700; font-size: 14px; border-top: 1px solid #e2e8f0; padding-top: 12px; }
            .notes { margin-top: 16px; padding: 16px; border-radius: 12px; background: #f8fafc; border: 1px solid #e2e8f0; }
            .payment { margin-top: 24px; padding: 18px; border-radius: 12px; background: rgba(59,130,246,0.08); border: 1px solid rgba(59,130,246,0.2); }
            .payment strong { display: block; font-size: 14px; margin-bottom: 6px; }
            .signature { margin-top: 36px; display: flex; justify-content: space-between; font-size: 12px; color: #6b7280; }
        </style>
    </head>
    <body>
        <div class="header">
            <div>
                <div class="brand"><?= htmlspecialchars($organization['name'] ?? 'FlowExpense') ?></div>
                <h1>Onkostennota <?= htmlspecialchars($report['custom_id'] ?: '#' . $report['id']) ?></h1>
                <div>Opgesteld op <?= htmlspecialchars($report['date'] ?? date('Y-m-d')) ?></div>
            </div>
            <div class="meta">
                <strong>Betaal aan</strong>
                <div><?= nl2br(htmlspecialchars(trim(($report['recipient'] ?? '') . "\n" . ($report['address'] ?? '')))) ?></div>
                <div style="margin-top:10px;">IBAN: <?= htmlspecialchars($report['iban'] ?? '') ?></div>
                <div>Bank: <?= htmlspecialchars($report['bank_name'] ?? '') ?></div>
            </div>
        </div>

        <div class="section info-grid">
            <div class="info-card">
                <strong>Ontvanger</strong>
                <span><?= htmlspecialchars($report['recipient'] ?? '') ?></span>
                <span><?= nl2br(htmlspecialchars($report['address'] ?? '')) ?></span>
            </div>
            <div class="info-card">
                <strong>Organisatie</strong>
                <span><?= htmlspecialchars($organization['legal_name'] ?? $organization['name'] ?? '') ?></span>
                <span><?= nl2br(htmlspecialchars($orgAddress)) ?></span>
            </div>
            <div class="info-card">
                <strong>Referenties</strong>
                <span>BTW: <?= htmlspecialchars($organization['vat_number'] ?? '-') ?></span>
                <span>IBAN: <?= htmlspecialchars($organization['iban'] ?? '-') ?></span>
                <span>Bank: <?= htmlspecialchars($organization['bank_name'] ?? '-') ?></span>
            </div>
        </div>

        <div class="section">
            <h2>Details</h2>
            <table>
                <thead>
                <tr>
                    <th>Omschrijving</th>
                    <th>Aantal</th>
                    <th>Eenheid</th>
                    <th>Prijs per eenheid</th>
                    <th>Subtotaal</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lines as $line):
                    $quantity = (float)($line['quantity'] ?? 0);
                    $rate = (float)($line['rate'] ?? 0);
                    $subtotal = $quantity * $rate;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($line['description'] ?? '') ?></td>
                        <td><?= number_format($quantity, 2, ',', '.') ?></td>
                        <td><?= htmlspecialchars($line['unit'] ?? '-') ?></td>
                        <td>€ <?= number_format($rate, 4, ',', '.') ?></td>
                        <td>€ <?= number_format($subtotal, 2, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div class="totals">
                <table>
                    <tr>
                        <td>Totaal</td>
                        <td style="text-align:right;">€ <?= number_format($total, 2, ',', '.') ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <?php if ($renderedDescription): ?>
            <div class="notes">
                <h3>Omschrijving &amp; Doel</h3>
                <?= $renderedDescription ?>
            </div>
        <?php endif; ?>

        <div class="payment">
            <strong>Betalingsinformatie</strong>
            <div>Gelieve het totaalbedrag van € <?= number_format($total, 2, ',', '.') ?> over te maken naar <?= htmlspecialchars($report['iban'] ?? '') ?> ten name van <?= htmlspecialchars($report['recipient'] ?? '') ?>.</div>
            <div>Vermeld referentie <?= htmlspecialchars($report['custom_id'] ?: '#' . $report['id']) ?> bij de betaling.</div>
        </div>

        <div class="signature">
            <div>Goedgekeurd door <?= htmlspecialchars($organization['legal_name'] ?? $organization['name'] ?? '') ?></div>
            <div>Contact: <?= htmlspecialchars($organization['contact_email'] ?? ($organization['phone'] ?? '')) ?></div>
        </div>
    </body>
    </html>
    <?php
    return ob_get_clean();
}
