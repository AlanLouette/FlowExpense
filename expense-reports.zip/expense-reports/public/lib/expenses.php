<?php
function generate_custom_id(PDO $db, int $organizationId): string
{
    $stmt = $db->prepare('SELECT number_prefix, next_expense_number FROM organizations WHERE id = ?');
    $stmt->execute([$organizationId]);
    $orgData = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$orgData) {
        throw new RuntimeException('Organisatie-instellingen niet gevonden.');
    }
    $prefix = $orgData['number_prefix'] ?: 'EXP';
    $sequence = (int)$orgData['next_expense_number'];

    do {
        $candidate = sprintf('%s-%04d', $prefix, $sequence);
        $check = $db->prepare('SELECT COUNT(*) FROM expense_reports WHERE organization_id = ? AND custom_id = ?');
        $check->execute([$organizationId, $candidate]);
        if ($check->fetchColumn() == 0) {
            break;
        }
        $sequence++;
    } while (true);

    $updateOrg = $db->prepare('UPDATE organizations SET next_expense_number = ? WHERE id = ?');
    $updateOrg->execute([$sequence + 1, $organizationId]);

    return $candidate;
}

function ensure_unique_custom_id(PDO $db, int $organizationId, string $customId, ?int $excludeId = null): void
{
    $query = 'SELECT COUNT(*) FROM expense_reports WHERE organization_id = ? AND custom_id = ?';
    $params = [$organizationId, $customId];
    if ($excludeId) {
        $query .= ' AND id != ?';
        $params[] = $excludeId;
    }
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    if ($stmt->fetchColumn() > 0) {
        throw new RuntimeException('Dit onkostennota-nummer is al in gebruik.');
    }
}
