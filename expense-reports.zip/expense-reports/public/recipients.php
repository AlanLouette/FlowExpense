<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];
$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $name = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $iban = trim($_POST['iban'] ?? '');
    $bank = trim($_POST['bank_name'] ?? '');

    if ($name === '' || $address === '' || $iban === '' || $bank === '') {
        http_response_code(400);
        exit('Alle velden zijn verplicht.');
    }

    if ($id) {
        $stmt = $db->prepare('UPDATE recipients SET name = ?, address = ?, iban = ?, bank_name = ? WHERE id = ? AND organization_id = ?');
        $stmt->execute([$name, $address, $iban, $bank, $id, $orgId]);
    } else {
        $stmt = $db->prepare('INSERT INTO recipients (organization_id, name, address, iban, bank_name) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$orgId, $name, $address, $iban, $bank]);
    }

    header('Location: recipients.php');
    exit;
}

if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $stmt = $db->prepare('DELETE FROM recipients WHERE id = ? AND organization_id = ?');
    $stmt->execute([$deleteId, $orgId]);
    header('Location: recipients.php');
    exit;
}

$editRecipient = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $db->prepare('SELECT * FROM recipients WHERE id = ? AND organization_id = ?');
    $stmt->execute([$editId, $orgId]);
    $editRecipient = $stmt->fetch(PDO::FETCH_ASSOC);
}

$stmt = $db->prepare('SELECT * FROM recipients WHERE organization_id = ? ORDER BY name ASC');
$stmt->execute([$orgId]);
$recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);

renderPageStart('Ontvangers', 'recipients');
?>
<section class="card">
    <h2><?= $editRecipient ? 'Ontvanger bijwerken' : 'Nieuwe ontvanger' ?></h2>
    <form method="post">
        <div class="grid-2">
            <label>Naam
                <input type="text" name="name" required value="<?= htmlspecialchars($editRecipient['name'] ?? '') ?>">
            </label>
            <label>Adres
                <input type="text" name="address" required value="<?= htmlspecialchars($editRecipient['address'] ?? '') ?>">
            </label>
            <label>IBAN
                <input type="text" name="iban" required value="<?= htmlspecialchars($editRecipient['iban'] ?? '') ?>">
            </label>
            <label>Bank
                <input type="text" name="bank_name" required value="<?= htmlspecialchars($editRecipient['bank_name'] ?? '') ?>">
            </label>
        </div>
        <?php if ($editRecipient): ?>
            <input type="hidden" name="id" value="<?= (int)$editRecipient['id'] ?>">
        <?php endif; ?>
        <div style="display:flex;gap:12px;justify-content:flex-end;">
            <button type="submit"><?= $editRecipient ? 'Bijwerken' : 'Toevoegen' ?></button>
            <?php if ($editRecipient): ?>
                <a class="button" href="recipients.php" style="display:inline-flex;align-items:center;background:linear-gradient(135deg,#9ca3af,#6b7280);padding:10px 18px;">Annuleren</a>
            <?php endif; ?>
        </div>
    </form>
</section>

<section class="card">
    <h2>Huidige ontvangers</h2>
    <?php if (empty($recipients)): ?>
        <p class="notice">Er zijn nog geen ontvangers aangemaakt voor deze organisatie.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Naam</th>
                <th>Adres</th>
                <th>IBAN</th>
                <th>Bank</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($recipients as $recipient): ?>
                <tr>
                    <td><?= htmlspecialchars($recipient['name']) ?></td>
                    <td><?= htmlspecialchars($recipient['address']) ?></td>
                    <td><?= htmlspecialchars($recipient['iban']) ?></td>
                    <td><?= htmlspecialchars($recipient['bank_name']) ?></td>
                    <td class="table-actions">
                        <a href="recipients.php?edit=<?= (int)$recipient['id'] ?>">Bewerken</a>
                        <a href="recipient-detail.php?id=<?= (int)$recipient['id'] ?>">Bekijk</a>
                        <a href="recipient-export.php?id=<?= (int)$recipient['id'] ?>">Export</a>
                        <a href="?delete=<?= (int)$recipient['id'] ?>" onclick="return confirm('Ontvanger verwijderen?');">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php
renderPageEnd();
