<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $name = trim($_POST['name'] ?? '');

    if ($name === '') {
        http_response_code(400);
        exit('Naam is verplicht.');
    }

    if ($id) {
        $stmt = $db->prepare('UPDATE expense_categories SET name = ? WHERE id = ? AND organization_id = ?');
        $stmt->execute([$name, $id, $orgId]);
    } else {
        $stmt = $db->prepare('INSERT INTO expense_categories (organization_id, name) VALUES (?, ?)');
        $stmt->execute([$orgId, $name]);
    }

    header('Location: categories.php');
    exit;
}

if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $db->prepare('UPDATE expense_reports SET category_id = NULL WHERE category_id = ?')->execute([$deleteId]);
    $stmt = $db->prepare('DELETE FROM expense_categories WHERE id = ? AND organization_id = ?');
    $stmt->execute([$deleteId, $orgId]);
    header('Location: categories.php');
    exit;
}

$editCategory = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $db->prepare('SELECT * FROM expense_categories WHERE id = ? AND organization_id = ?');
    $stmt->execute([$editId, $orgId]);
    $editCategory = $stmt->fetch(PDO::FETCH_ASSOC);
}

$stmt = $db->prepare('SELECT * FROM expense_categories WHERE organization_id = ? ORDER BY name ASC');
$stmt->execute([$orgId]);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

renderPageStart('Categorieën', 'categories');
?>
<section class="card">
    <h2><?= $editCategory ? 'Categorie bijwerken' : 'Nieuwe categorie' ?></h2>
    <form method="post">
        <label>Naam
            <input type="text" name="name" required value="<?= htmlspecialchars($editCategory['name'] ?? '') ?>">
        </label>
        <?php if ($editCategory): ?>
            <input type="hidden" name="id" value="<?= (int)$editCategory['id'] ?>">
        <?php endif; ?>
        <div style="display:flex;gap:12px;justify-content:flex-end;">
            <button type="submit"><?= $editCategory ? 'Bijwerken' : 'Toevoegen' ?></button>
            <?php if ($editCategory): ?>
                <a class="button" href="categories.php" style="display:inline-flex;align-items:center;background:linear-gradient(135deg,#9ca3af,#6b7280);padding:10px 18px;">Annuleren</a>
            <?php endif; ?>
        </div>
    </form>
</section>

<section class="card">
    <h2>Bestaande categorieën</h2>
    <?php if (empty($categories)): ?>
        <p class="notice">Er zijn nog geen categorieën aangemaakt.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Naam</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($categories as $category): ?>
                <tr>
                    <td><?= htmlspecialchars($category['name']) ?></td>
                    <td class="table-actions">
                        <a href="categories.php?edit=<?= (int)$category['id'] ?>">Bewerken</a>
                        <a href="?delete=<?= (int)$category['id'] ?>" onclick="return confirm('Categorie verwijderen? Gekoppelde onkostennota\'s verliezen hun categorie.');">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php
renderPageEnd();
