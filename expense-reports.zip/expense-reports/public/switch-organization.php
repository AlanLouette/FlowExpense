<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();

$organizationId = isset($_POST['organization_id']) ? (int)$_POST['organization_id'] : 0;

$allowed = false;
foreach ($availableOrganizations as $org) {
    if ((int)$org['id'] === $organizationId) {
        $allowed = true;
        break;
    }
}

if ($allowed) {
    $_SESSION['organization_id'] = $organizationId;
}

$redirect = $_SERVER['HTTP_REFERER'] ?? 'index.php';
header('Location: ' . $redirect);
exit;
