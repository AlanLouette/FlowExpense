<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$redirect = $_POST['redirect'] ?? 'index.php';

if ($id <= 0) {
    http_response_code(400);
    exit('Ongeldig ID.');
}

$stmt = $db->prepare('SELECT a.stored_name, a.report_id, r.organization_id, r.user_id FROM expense_attachments a INNER JOIN expense_reports r ON r.id = a.report_id WHERE a.id = ?');
$stmt->execute([$id]);
$attachment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$attachment || (int)$attachment['organization_id'] !== (int)$currentOrganization['id']) {
    http_response_code(404);
    exit('Bijlage niet gevonden.');
}

$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;
if (!$isAdmin && (int)$attachment['user_id'] !== (int)$currentUser['id']) {
    http_response_code(403);
    exit('Geen toestemming om deze bijlage te verwijderen.');
}

$path = '/var/www/data/attachments/' . $attachment['stored_name'];
if (is_file($path)) {
    @unlink($path);
}

$db->prepare('DELETE FROM expense_attachments WHERE id = ?')->execute([$id]);
header('Location: ' . $redirect);
exit;
