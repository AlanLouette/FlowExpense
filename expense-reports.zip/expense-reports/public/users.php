<?php
require_once __DIR__ . '/bootstrap.php';
requireAdmin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/layout.php';

$allOrganizations = $db->query('SELECT id, name FROM organizations ORDER BY name ASC')->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $isAdmin = isset($_POST['is_admin']) ? 1 : 0;
        $orgIds = array_map('intval', $_POST['organization_ids'] ?? []);

        if ($name === '' || $email === '' || $password === '') {
            http_response_code(400);
            exit('Alle velden zijn verplicht.');
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare('INSERT INTO users (name, email, password_hash, is_admin, active) VALUES (?, ?, ?, ?, 1)');
        $stmt->execute([$name, $email, $hash, $isAdmin]);
        $userId = (int)$db->lastInsertId();

        $insertMembership = $db->prepare('INSERT OR IGNORE INTO user_organizations (user_id, organization_id, role) VALUES (?, ?, ?)');
        foreach ($orgIds as $orgId) {
            $insertMembership->execute([$userId, $orgId, $isAdmin ? 'admin' : 'member']);
        }

        header('Location: users.php');
        exit;
    }

    $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    if ($userId <= 0) {
        http_response_code(400);
        exit('Ongeldige gebruiker.');
    }

    if ($action === 'toggle_active') {
        $db->prepare('UPDATE users SET active = CASE WHEN active = 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([$userId]);
    } elseif ($action === 'toggle_admin') {
        if ($userId === (int)$currentUser['id']) {
            http_response_code(400);
            exit('Kan eigen adminstatus niet wijzigen.');
        }
        $db->prepare('UPDATE users SET is_admin = CASE WHEN is_admin = 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([$userId]);
    } elseif ($action === 'reset_password') {
        $password = $_POST['new_password'] ?? '';
        if ($password === '') {
            http_response_code(400);
            exit('Wachtwoord mag niet leeg zijn.');
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $db->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([$hash, $userId]);
    } elseif ($action === 'update_membership') {
        $orgIds = array_map('intval', $_POST['organization_ids'] ?? []);
        $db->prepare('DELETE FROM user_organizations WHERE user_id = ?')->execute([$userId]);
        $user = $db->prepare('SELECT is_admin FROM users WHERE id = ?');
        $user->execute([$userId]);
        $userData = $user->fetch(PDO::FETCH_ASSOC);
        $role = (!empty($userData) && (int)$userData['is_admin'] === 1) ? 'admin' : 'member';
        $insertMembership = $db->prepare('INSERT OR IGNORE INTO user_organizations (user_id, organization_id, role) VALUES (?, ?, ?)');
        foreach ($orgIds as $orgId) {
            $insertMembership->execute([$userId, $orgId, $role]);
        }
    }

    header('Location: users.php');
    exit;
}

$users = $db->query('SELECT * FROM users ORDER BY name ASC')->fetchAll(PDO::FETCH_ASSOC);
$userOrgMap = [];
if ($users) {
    $userIds = array_column($users, 'id');
    $placeholders = implode(',', array_fill(0, count($userIds), '?'));
    $stmt = $db->prepare("SELECT uo.user_id, o.id AS org_id, o.name FROM user_organizations uo INNER JOIN organizations o ON o.id = uo.organization_id WHERE uo.user_id IN ($placeholders) ORDER BY o.name");
    $stmt->execute($userIds);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $userOrgMap[(int)$row['user_id']][] = $row;
    }
}

renderPageStart('Gebruikersbeheer', 'users');
?>
<section class="card">
    <h2>Nieuwe gebruiker</h2>
    <form method="post">
        <input type="hidden" name="action" value="create">
        <div class="grid-2">
            <label>Naam
                <input type="text" name="name" required>
            </label>
            <label>E-mailadres
                <input type="email" name="email" required>
            </label>
            <label>Wachtwoord
                <input type="password" name="password" required>
            </label>
            <label>Rol
                <span style="display:flex;align-items:center;gap:8px;">
                    <input type="checkbox" name="is_admin" value="1"> Beheerder
                </span>
            </label>
            <label>Organisaties
                <select name="organization_ids[]" multiple size="<?= max(3, count($allOrganizations)) ?>">
                    <?php foreach ($allOrganizations as $org): ?>
                        <option value="<?= (int)$org['id'] ?>" <?= (int)$org['id'] === (int)$currentOrganization['id'] ? 'selected' : '' ?>><?= htmlspecialchars($org['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <div style="display:flex;justify-content:flex-end;">
            <button type="submit">Gebruiker aanmaken</button>
        </div>
    </form>
</section>

<section class="card">
    <h2>Bestaande gebruikers</h2>
    <table>
        <thead>
        <tr>
            <th>Naam</th>
            <th>E-mail</th>
            <th>Rol</th>
            <th>Organisaties</th>
            <th>Status</th>
            <th>Acties</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $user): ?>
            <?php $userId = (int)$user['id']; ?>
            <tr>
                <td><?= htmlspecialchars($user['name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= (int)$user['is_admin'] === 1 ? 'Beheerder' : 'Gebruiker' ?></td>
                <td>
                    <form method="post" style="display:flex;gap:8px;align-items:center;">
                        <input type="hidden" name="action" value="update_membership">
                        <input type="hidden" name="user_id" value="<?= $userId ?>">
                        <select name="organization_ids[]" multiple size="<?= max(3, count($allOrganizations)) ?>">
                            <?php $assigned = $userOrgMap[$userId] ?? []; $assignedIds = array_column($assigned, 'org_id'); ?>
                            <?php foreach ($allOrganizations as $org): ?>
                                <option value="<?= (int)$org['id'] ?>" <?= in_array($org['id'], $assignedIds ?? [], true) ? 'selected' : '' ?>><?= htmlspecialchars($org['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit">Opslaan</button>
                    </form>
                </td>
                <td><?= (int)$user['active'] === 1 ? 'Actief' : 'Inactief' ?></td>
                <td class="table-actions" style="min-width:200px;">
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="action" value="toggle_active">
                        <input type="hidden" name="user_id" value="<?= $userId ?>">
                        <button type="submit" style="background:linear-gradient(135deg,#6366f1,#4338ca);color:#fff;padding:6px 12px;border:none;border-radius:8px;cursor:pointer;"><?= (int)$user['active'] === 1 ? 'Deactiveer' : 'Activeer' ?></button>
                    </form>
                    <form method="post" style="display:inline;" onsubmit="return confirm('Wachtwoord resetten?');">
                        <input type="hidden" name="action" value="reset_password">
                        <input type="hidden" name="user_id" value="<?= $userId ?>">
                        <input type="password" name="new_password" placeholder="Nieuw wachtwoord" required style="padding:6px 8px;border-radius:6px;border:1px solid var(--color-border);">
                        <button type="submit" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff;padding:6px 12px;border:none;border-radius:8px;cursor:pointer;">Reset</button>
                    </form>
                    <form method="post" style="display:inline;" <?= $userId === (int)$currentUser['id'] ? 'onsubmit="return alert(\'Kan eigen adminstatus niet wijzigen.\');"' : '' ?>>
                        <input type="hidden" name="action" value="toggle_admin">
                        <input type="hidden" name="user_id" value="<?= $userId ?>">
                        <button type="submit" style="background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;padding:6px 12px;border:none;border-radius:8px;cursor:pointer;" <?= $userId === (int)$currentUser['id'] ? 'disabled' : '' ?>><?= (int)$user['is_admin'] === 1 ? 'Maak gebruiker' : 'Maak admin' ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php
renderPageEnd();
