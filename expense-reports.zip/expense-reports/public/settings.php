<?php
require_once __DIR__ . '/bootstrap.php';
requireAdmin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $legalName = trim($_POST['legal_name'] ?? '');
    $address1 = trim($_POST['address_line1'] ?? '');
    $address2 = trim($_POST['address_line2'] ?? '');
    $postal = trim($_POST['postal_code'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $vat = trim($_POST['vat_number'] ?? '');
    $iban = trim($_POST['iban'] ?? '');
    $bank = trim($_POST['bank_name'] ?? '');
    $contact = trim($_POST['contact_email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $prefix = trim($_POST['number_prefix'] ?? 'EXP');
    $nextNumber = max(1, (int)($_POST['next_expense_number'] ?? 1));
    $primary = trim($_POST['branding_primary'] ?? '#1f2933');
    $accent = trim($_POST['branding_accent'] ?? '#3b82f6');

    $stmt = $db->prepare('UPDATE organizations SET legal_name = ?, address_line1 = ?, address_line2 = ?, postal_code = ?, city = ?, country = ?, vat_number = ?, iban = ?, bank_name = ?, contact_email = ?, phone = ?, number_prefix = ?, next_expense_number = ?, branding_primary = ?, branding_accent = ? WHERE id = ?');
    $stmt->execute([
        $legalName,
        $address1,
        $address2,
        $postal,
        $city,
        $country,
        $vat,
        $iban,
        $bank,
        $contact,
        $phone,
        $prefix ?: 'EXP',
        $nextNumber,
        $primary,
        $accent,
        $orgId
    ]);

    $_SESSION['flash_message'] = 'Instellingen opgeslagen.';
    header('Location: settings.php');
    exit;
}

$stmt = $db->prepare('SELECT * FROM organizations WHERE id = ?');
$stmt->execute([$orgId]);
$organization = $stmt->fetch(PDO::FETCH_ASSOC);

$flash = $_SESSION['flash_message'] ?? null;
unset($_SESSION['flash_message']);

renderPageStart('Instellingen', 'settings');
?>
<section class="card">
    <h2>Organisatiegegevens</h2>
    <?php if ($flash): ?>
        <p class="notice"><?= htmlspecialchars($flash) ?></p>
    <?php endif; ?>
    <form method="post">
        <div class="grid-2">
            <label>Juridische naam
                <input type="text" name="legal_name" value="<?= htmlspecialchars($organization['legal_name'] ?? '') ?>">
            </label>
            <label>Adres regel 1
                <input type="text" name="address_line1" value="<?= htmlspecialchars($organization['address_line1'] ?? '') ?>">
            </label>
            <label>Adres regel 2
                <input type="text" name="address_line2" value="<?= htmlspecialchars($organization['address_line2'] ?? '') ?>">
            </label>
            <label>Postcode
                <input type="text" name="postal_code" value="<?= htmlspecialchars($organization['postal_code'] ?? '') ?>">
            </label>
            <label>Stad
                <input type="text" name="city" value="<?= htmlspecialchars($organization['city'] ?? '') ?>">
            </label>
            <label>Land
                <input type="text" name="country" value="<?= htmlspecialchars($organization['country'] ?? '') ?>">
            </label>
            <label>BTW-nummer
                <input type="text" name="vat_number" value="<?= htmlspecialchars($organization['vat_number'] ?? '') ?>">
            </label>
            <label>IBAN
                <input type="text" name="iban" value="<?= htmlspecialchars($organization['iban'] ?? '') ?>">
            </label>
            <label>Bank
                <input type="text" name="bank_name" value="<?= htmlspecialchars($organization['bank_name'] ?? '') ?>">
            </label>
            <label>Contact e-mail
                <input type="email" name="contact_email" value="<?= htmlspecialchars($organization['contact_email'] ?? '') ?>">
            </label>
            <label>Telefoon
                <input type="text" name="phone" value="<?= htmlspecialchars($organization['phone'] ?? '') ?>">
            </label>
            <label>Nummer prefix
                <input type="text" name="number_prefix" value="<?= htmlspecialchars($organization['number_prefix'] ?? 'EXP') ?>">
            </label>
            <label>Volgend onkostennummer
                <input type="number" name="next_expense_number" min="1" value="<?= htmlspecialchars($organization['next_expense_number'] ?? 1) ?>">
            </label>
            <label>Primaire kleur
                <input type="color" name="branding_primary" value="<?= htmlspecialchars($organization['branding_primary'] ?? '#1f2933') ?>">
            </label>
            <label>Accentkleur
                <input type="color" name="branding_accent" value="<?= htmlspecialchars($organization['branding_accent'] ?? '#3b82f6') ?>">
            </label>
        </div>
        <div style="display:flex;justify-content:flex-end;margin-top:16px;">
            <button type="submit">Opslaan</button>
        </div>
    </form>
</section>
<?php
renderPageEnd();
