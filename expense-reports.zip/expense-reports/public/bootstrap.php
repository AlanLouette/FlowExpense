<?php
require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

loadDotEnv(__DIR__ . '/../.env');

function loadDotEnv(string $path): void
{
    if (!is_file($path) || !is_readable($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return;
    }

    foreach ($lines as $rawLine) {
        $line = trim($rawLine);
        if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
            continue;
        }

        if (stripos($line, 'export ') === 0) {
            $line = trim(substr($line, 7));
        }

        [$name, $value] = array_map('trim', explode('=', $line, 2));
        if ($name === '') {
            continue;
        }

        if ($value !== '' && (($value[0] === '"' && substr($value, -1) === '"') || ($value[0] === "'" && substr($value, -1) === "'"))) {
            $value = substr($value, 1, -1);
        }

        $value = str_replace(['\n', '\r'], ["\n", "\r"], $value);

        if (getenv($name) !== false) {
            continue;
        }

        putenv($name . '=' . $value);
        $_ENV[$name] = $value;
        $_SERVER[$name] = $value;
    }
}


function env(string $key, ?string $default = null): ?string
{
    $value = getenv($key);
    return ($value === false) ? $default : $value;
}

function ensureDefaultOrganization(PDO $db): int
{
    $existing = $db->query('SELECT id FROM organizations ORDER BY id ASC LIMIT 1')->fetchColumn();
    if ($existing) {
        return (int)$existing;
    }

    $name = env('DEFAULT_ORG_NAME', 'Main Organization');
    $legal = env('DEFAULT_ORG_LEGAL_NAME', $name);
    $address1 = env('DEFAULT_ORG_ADDRESS_LINE1', 'Straatnaam 1');
    $address2 = env('DEFAULT_ORG_ADDRESS_LINE2', '');
    $postal = env('DEFAULT_ORG_POSTAL', '1000');
    $city = env('DEFAULT_ORG_CITY', 'Brussel');
    $country = env('DEFAULT_ORG_COUNTRY', 'België');
    $vat = env('DEFAULT_ORG_VAT', 'BE0000000000');
    $iban = env('DEFAULT_ORG_IBAN', 'BE00 0000 0000 0000');
    $bank = env('DEFAULT_ORG_BANK', 'FinBank');
    $primary = env('DEFAULT_ORG_COLOR_PRIMARY', '#1f2933');
    $accent = env('DEFAULT_ORG_COLOR_ACCENT', '#3b82f6');
    $prefix = env('DEFAULT_ORG_NUMBER_PREFIX', 'EXP');
    $next = (int)env('DEFAULT_ORG_NEXT_NUMBER', '1');

    $stmt = $db->prepare('INSERT INTO organizations (name, legal_name, address_line1, address_line2, postal_code, city, country, vat_number, iban, bank_name, branding_primary, branding_accent, number_prefix, next_expense_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $name,
        $legal,
        $address1,
        $address2,
        $postal,
        $city,
        $country,
        $vat,
        $iban,
        $bank,
        $primary,
        $accent,
        $prefix,
        $next
    ]);

    return (int)$db->lastInsertId();
}

function ensureAdminUser(PDO $db, int $organizationId): array
{
    $email = env('ADMIN_EMAIL', 'admin@example.com');
    $name = env('ADMIN_NAME', 'Administrator');
    $password = env('ADMIN_PASSWORD', 'changeme123');

    $stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $insert = $db->prepare('INSERT INTO users (name, email, password_hash, is_admin, active) VALUES (?, ?, ?, 1, 1)');
        $insert->execute([$name, $email, $hash]);
        $userId = (int)$db->lastInsertId();
    } else {
        $userId = (int)$user['id'];
        if (!password_verify($password, $user['password_hash'])) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare('UPDATE users SET password_hash = ?, active = 1 WHERE id = ?')->execute([$newHash, $userId]);
        }
    }

    $link = $db->prepare('INSERT OR IGNORE INTO user_organizations (user_id, organization_id, role) VALUES (?, ?, ?)');
    $link->execute([$userId, $organizationId, 'admin']);

    $stmt = $db->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}

function backfillOrganizationData(PDO $db, int $organizationId): void
{
    $db->exec('UPDATE recipients SET organization_id = ' . (int)$organizationId . ' WHERE organization_id IS NULL');
    $db->exec('UPDATE expense_categories SET organization_id = ' . (int)$organizationId . ' WHERE organization_id IS NULL');
    $db->exec('UPDATE units SET organization_id = ' . (int)$organizationId . ' WHERE organization_id IS NULL');
    $db->exec('UPDATE expense_reports SET organization_id = ' . (int)$organizationId . ' WHERE organization_id IS NULL');
}

$defaultOrgId = ensureDefaultOrganization($db);
$defaultAdmin = ensureAdminUser($db, $defaultOrgId);
backfillOrganizationData($db, $defaultOrgId);

if (!empty($defaultAdmin) && $db->query('SELECT COUNT(*) FROM expense_reports WHERE user_id IS NULL')->fetchColumn() > 0) {
    $update = $db->prepare('UPDATE expense_reports SET user_id = ? WHERE user_id IS NULL');
    $update->execute([$defaultAdmin['id']]);
}

$currentUser = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $db->prepare('SELECT * FROM users WHERE id = ? AND active = 1');
    $stmt->execute([$_SESSION['user_id']]);
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$currentUser) {
        unset($_SESSION['user_id']);
    }
}

function requireLogin(bool $redirect = true): void
{
    global $currentUser;
    if ($currentUser) {
        return;
    }

    if ($redirect) {
        $target = urlencode($_SERVER['REQUEST_URI'] ?? 'index.php');
        header('Location: login.php?redirect=' . $target);
        exit;
    }

    http_response_code(401);
    exit('Authentication required.');
}

function requireAdmin(): void
{
    global $currentUser;
    requireLogin();
    if (!$currentUser || (int)$currentUser['is_admin'] !== 1) {
        http_response_code(403);
        exit('Admin privileges required.');
    }
}

function fetchUserOrganizations(PDO $db, int $userId): array
{
    $stmt = $db->prepare('SELECT o.*, uo.role FROM organizations o INNER JOIN user_organizations uo ON uo.organization_id = o.id WHERE uo.user_id = ? ORDER BY o.name');
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$currentOrganization = null;
$availableOrganizations = [];
if ($currentUser) {
    $availableOrganizations = fetchUserOrganizations($db, (int)$currentUser['id']);
    $requestedOrgId = $_SESSION['organization_id'] ?? null;

    foreach ($availableOrganizations as $org) {
        if ($requestedOrgId && (int)$requestedOrgId === (int)$org['id']) {
            $currentOrganization = $org;
            break;
        }
    }

    if (!$currentOrganization && !empty($availableOrganizations)) {
        $currentOrganization = $availableOrganizations[0];
        $_SESSION['organization_id'] = (int)$currentOrganization['id'];
    }
}

function enforceOrganizationAccess(?array $organization): void
{
    if (!$organization) {
        requireLogin();
        http_response_code(403);
        exit('No organization selected.');
    }
}