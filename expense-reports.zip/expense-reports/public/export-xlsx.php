<?php
ob_start();
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    ob_end_clean();
    http_response_code(400);
    exit('Ongeldig ID.');
}

$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

$stmt = $db->prepare('SELECT * FROM expense_reports WHERE id = ? AND organization_id = ?');
$stmt->execute([$id, (int)$currentOrganization['id']]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$report) {
    ob_end_clean();
    http_response_code(404);
    exit('Onkostennota niet gevonden.');
}

if (!$isAdmin && (int)$report['user_id'] !== (int)$currentUser['id']) {
    ob_end_clean();
    http_response_code(403);
    exit('Geen toegang tot deze onkostennota.');
}

$linesStmt = $db->prepare('SELECT description, quantity, unit, rate FROM expense_lines WHERE report_id = ? ORDER BY id ASC');
$linesStmt->execute([$id]);
$lines = $linesStmt->fetchAll(PDO::FETCH_ASSOC);

$customId = $report['custom_id'] ?: sprintf('EXP-%04d', $report['id']);

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Onkostennota');

$sheet->setCellValue('A1', 'Onkostennota');
$sheet->setCellValue('B1', $customId);
$sheet->setCellValue('A3', 'Ontvanger');
$sheet->setCellValue('B3', $report['recipient'] ?? '');
$sheet->setCellValue('A4', 'Adres');
$sheet->setCellValue('B4', $report['address'] ?? '');
$sheet->setCellValue('A5', 'IBAN');
$sheet->setCellValue('B5', $report['iban'] ?? '');
$sheet->setCellValue('A6', 'Bank');
$sheet->setCellValue('B6', $report['bank_name'] ?? '');
$sheet->setCellValue('A7', 'Datum');
$sheet->setCellValue('B7', $report['date'] ?? '');
$sheet->setCellValue('A8', 'Omschrijving');
$sheet->setCellValue('B8', $report['description'] ?? '');

$sheet->setCellValue('A10', 'Omschrijving');
$sheet->setCellValue('B10', 'Aantal');
$sheet->setCellValue('C10', 'Eenheid');
$sheet->setCellValue('D10', 'Prijs per eenheid');
$sheet->setCellValue('E10', 'Subtotaal');

$row = 11;
foreach ($lines as $line) {
    $quantity = (float)($line['quantity'] ?? 0);
    $rate = (float)($line['rate'] ?? 0);
    $sheet->setCellValue("A{$row}", $line['description'] ?? '');
    $sheet->setCellValue("B{$row}", $quantity);
    $sheet->setCellValue("C{$row}", $line['unit'] ?? '');
    $sheet->setCellValue("D{$row}", $rate);
    $sheet->setCellValue("E{$row}", $quantity * $rate);
    $row++;
}

$sheet->setCellValue("D{$row}", 'Totaal');
$sheet->setCellValue("E{$row}", (float)($report['total'] ?? 0));

$filename = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $customId) . '.xlsx';

ob_end_clean();
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
