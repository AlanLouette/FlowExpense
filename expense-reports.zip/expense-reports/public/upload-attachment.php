<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);

$reportId = isset($_POST['report_id']) ? (int)$_POST['report_id'] : 0;
if ($reportId <= 0) {
    http_response_code(400);
    exit('Ongeldig rapport.');
}

$redirect = $_POST['redirect'] ?? ('form.php?id=' . $reportId);

$stmt = $db->prepare('SELECT organization_id, user_id FROM expense_reports WHERE id = ?');
$stmt->execute([$reportId]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$report || (int)$report['organization_id'] !== (int)$currentOrganization['id']) {
    http_response_code(404);
    exit('Onkostennota niet gevonden.');
}

$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;
if (!$isAdmin && (int)$report['user_id'] !== (int)$currentUser['id']) {
    http_response_code(403);
    exit('Geen toestemming om bijlagen toe te voegen.');
}

$dir = '/var/www/data/attachments';
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}

$allowedExt = ['pdf', 'csv', 'xlsx', 'xls'];
$maxSize = 20 * 1024 * 1024;

if (!isset($_FILES['files'])) {
    header('Location: ' . $redirect);
    exit;
}

$files = $_FILES['files'];
$count = is_array($files['name']) ? count($files['name']) : 0;

for ($i = 0; $i < $count; $i++) {
    if ($files['error'][$i] !== UPLOAD_ERR_OK) {
        continue;
    }
    if ($files['size'][$i] > $maxSize) {
        continue;
    }

    $orig = $files['name'][$i];
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        continue;
    }

    $safeOrig = preg_replace('/[^A-Za-z0-9 _.\-()+]/', '_', $orig);
    $stored = sprintf('%d_%s_%s.%s', $reportId, date('YmdHis'), bin2hex(random_bytes(4)), $ext);
    $dest = rtrim($dir, '/') . '/' . $stored;

    if (!move_uploaded_file($files['tmp_name'][$i], $dest)) {
        continue;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $dest) ?: null;
    finfo_close($finfo);

    $stmt = $db->prepare('INSERT INTO expense_attachments (report_id, original_name, stored_name, mime, size_bytes) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$reportId, $safeOrig, $stored, $mime, filesize($dest)]);
}

header('Location: ' . $redirect);
exit;
