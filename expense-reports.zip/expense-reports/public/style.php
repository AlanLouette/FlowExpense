<?php
require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$primary = '#1f2933';
$accent = '#3b82f6';
$organization = null;
if (isset($_SESSION['organization_id'])) {
    $stmt = $db->prepare('SELECT branding_primary, branding_accent FROM organizations WHERE id = ?');
    $stmt->execute([(int)$_SESSION['organization_id']]);
    $organization = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($organization) {
        $primary = $organization['branding_primary'] ?: $primary;
        $accent = $organization['branding_accent'] ?: $accent;
    }
}

header('Content-Type: text/css');
?>
:root {
    --color-primary: <?= $primary ?>;
    --color-accent: <?= $accent ?>;
    --color-surface: #ffffff;
    --color-muted: #6b7280;
    --color-border: #e5e7eb;
    --color-background: #f4f6fb;
    --radius-lg: 16px;
    --radius-md: 12px;
    --radius-sm: 8px;
    --shadow-sm: 0 8px 16px rgba(15, 23, 42, 0.06);
    --shadow-md: 0 18px 30px rgba(15, 23, 42, 0.08);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: var(--color-background);
    color: #1f2937;
    font-size: 16px;
    line-height: 1.6;
}

a {
    color: var(--color-accent);
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.app-shell {
    display: grid;
    grid-template-columns: 260px 1fr;
    min-height: 100vh;
}

.app-sidebar {
    background: var(--color-surface);
    border-right: 1px solid var(--color-border);
    display: flex;
    flex-direction: column;
    padding: 28px 24px;
}

.sidebar-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 28px;
}

.logo-circle {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--color-accent), var(--color-primary));
    box-shadow: inset 0 0 0 2px rgba(255,255,255,0.2);
}

.brand {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--color-primary);
    letter-spacing: 0.02em;
}

.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 10px;
    flex: 1;
}

.nav-link {
    padding: 10px 14px;
    border-radius: var(--radius-sm);
    color: #111827;
    font-weight: 500;
    transition: background 0.2s ease, color 0.2s ease;
}

.nav-link:hover {
    background: rgba(59, 130, 246, 0.08);
}

.nav-link.active {
    background: linear-gradient(135deg, var(--color-accent), var(--color-primary));
    color: #fff;
    box-shadow: var(--shadow-sm);
}

.sidebar-footer {
    border-top: 1px solid var(--color-border);
    padding-top: 20px;
    margin-top: 30px;
}

.user-meta {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 12px;
}

.user-name {
    font-weight: 600;
    color: var(--color-primary);
}

.user-email {
    font-size: 0.85rem;
    color: var(--color-muted);
}

.logout-link {
    font-size: 0.9rem;
    color: var(--color-muted);
}

.app-content {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

.app-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 32px 40px 16px;
}

.app-topbar h1 {
    margin: 0;
    font-size: 1.75rem;
    font-weight: 600;
}

.org-subtitle {
    display: block;
    font-size: 0.9rem;
    color: var(--color-muted);
    margin-top: 4px;
}

.org-switcher {
    display: flex;
    flex-direction: column;
    gap: 6px;
    align-items: flex-start;
    font-size: 0.85rem;
    color: var(--color-muted);
}

.org-switcher select {
    padding: 8px 12px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--color-border);
    background: var(--color-surface);
    color: #111827;
    font-size: 0.95rem;
}

.app-main {
    padding: 0 40px 40px;
}

.card {
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    padding: 24px;
    box-shadow: var(--shadow-sm);
    margin-bottom: 24px;
}

button,
input[type="submit"],
.button {
    background: linear-gradient(135deg, var(--color-accent), var(--color-primary));
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    padding: 10px 18px;
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}

button:hover,
input[type="submit"]:hover,
.button:hover {
    transform: translateY(-1px);
    box-shadow: var(--shadow-sm);
}

button:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    box-shadow: none;
}

form {
    display: grid;
    gap: 18px;
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    padding: 24px;
    box-shadow: var(--shadow-sm);
    margin-bottom: 28px;
}

.grid-2 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
}

form .grid-2 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
}

label {
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 0.9rem;
    color: var(--color-muted);
}

input,
textarea,
select {
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: 10px 12px;
    font-size: 1rem;
    background: #f9fafb;
    color: #111827;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

input:focus,
textarea:focus,
select:focus {
    outline: none;
    border-color: var(--color-accent);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
}

textarea {
    min-height: 120px;
    resize: vertical;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    margin-bottom: 24px;
}

th,
td {
    padding: 14px 18px;
    text-align: left;
    border-bottom: 1px solid var(--color-border);
}

th {
    background: rgba(17, 24, 39, 0.03);
    font-weight: 600;
    font-size: 0.85rem;
    color: var(--color-muted);
    text-transform: uppercase;
    letter-spacing: 0.03em;
}

tbody tr:nth-child(even) {
    background: rgba(59, 130, 246, 0.04);
}

tbody tr:hover {
    background: rgba(59, 130, 246, 0.08);
}

.status-select {
    border-radius: var(--radius-sm);
    padding: 6px 10px;
    font-size: 0.9rem;
    border: 1px solid transparent;
    background: rgba(59, 130, 246, 0.1);
    color: var(--color-primary);
}

.badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 0.8rem;
    font-weight: 500;
    background: rgba(59, 130, 246, 0.12);
    color: var(--color-accent);
}

.table-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.table-actions a,
.table-actions button {
    background: none;
    border: none;
    color: var(--color-accent);
    padding: 0;
    cursor: pointer;
}

.table-actions button:hover,
.table-actions a:hover {
    text-decoration: underline;
}

.bulk-toolbar {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 18px;
}

.notice {
    padding: 16px;
    border-radius: var(--radius-md);
    background: rgba(59, 130, 246, 0.12);
    color: var(--color-primary);
    box-shadow: var(--shadow-sm);
}

.markdown-preview {
    border: 1px dashed var(--color-border);
    border-radius: var(--radius-sm);
    padding: 16px;
    background: #f9fafb;
    min-height: 120px;
}

.markdown-preview h1,
.markdown-preview h2,
.markdown-preview h3 {
    margin-top: 1.2em;
}

.markdown-preview ul,
.markdown-preview ol {
    padding-left: 1.2rem;
}

.markdown-preview code {
    background: rgba(15, 23, 42, 0.08);
    padding: 2px 6px;
    border-radius: 4px;
    font-family: 'JetBrains Mono', monospace;
}

@media (max-width: 1024px) {
    .app-shell {
        grid-template-columns: 1fr;
    }
    .app-sidebar {
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        padding: 16px 20px;
        border-right: none;
        border-bottom: 1px solid var(--color-border);
    }
    .sidebar-nav {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 8px;
    }
    .app-topbar {
        padding: 24px 20px 12px;
    }
    .app-main {
        padding: 0 20px 20px;
    }
}
