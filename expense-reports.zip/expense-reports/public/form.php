<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/lib/markdown.php';
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];
$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$editMode = $id !== null;

if ($editMode) {
    $stmt = $db->prepare('SELECT * FROM expense_reports WHERE id = ? AND organization_id = ?');
    $stmt->execute([$id, $orgId]);
    $report = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$report) {
        http_response_code(404);
        exit('Onkostennota niet gevonden.');
    }
    if (!$isAdmin && (int)$report['user_id'] !== (int)$currentUser['id']) {
        http_response_code(403);
        exit('Geen toegang tot deze onkostennota.');
    }
    $stmtLines = $db->prepare('SELECT * FROM expense_lines WHERE report_id = ? ORDER BY id ASC');
    $stmtLines->execute([$id]);
    $lines = $stmtLines->fetchAll(PDO::FETCH_ASSOC);
} else {
    $report = [
        'date' => date('Y-m-d'),
        'custom_id' => ''
    ];
    $lines = [[]];
}

$recipientsStmt = $db->prepare('SELECT * FROM recipients WHERE organization_id = ? ORDER BY name ASC');
$recipientsStmt->execute([$orgId]);
$recipients = $recipientsStmt->fetchAll(PDO::FETCH_ASSOC);

$categoriesStmt = $db->prepare('SELECT * FROM expense_categories WHERE organization_id = ? ORDER BY name ASC');
$categoriesStmt->execute([$orgId]);
$categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

$unitsStmt = $db->prepare('SELECT name FROM units WHERE organization_id = ? ORDER BY name ASC');
$unitsStmt->execute([$orgId]);
$unitOptions = $unitsStmt->fetchAll(PDO::FETCH_COLUMN);

$descriptionPreview = markdown_to_html($report['description'] ?? '');

$nextNumber = $report['custom_id'] ?? '';
if (!$editMode && !$nextNumber) {
    $orgInfo = $db->prepare('SELECT number_prefix, next_expense_number FROM organizations WHERE id = ?');
    $orgInfo->execute([$orgId]);
    $orgData = $orgInfo->fetch(PDO::FETCH_ASSOC);
    if ($orgData) {
        $nextNumber = sprintf('%s-%04d', $orgData['number_prefix'] ?: 'EXP', (int)$orgData['next_expense_number']);
    }
}

renderPageStart($editMode ? 'Onkostennota bewerken' : 'Nieuwe onkostennota', 'form');
?>
<section class="card">
    <h2><?= $editMode ? 'Onkostennota bijwerken' : 'Nieuwe onkostennota' ?></h2>
    <form action="save.php" method="post" id="reportForm">
        <?php if ($editMode): ?>
            <input type="hidden" name="id" value="<?= (int)$id ?>">
        <?php endif; ?>
        <div class="grid-2">
            <label>Onkostennota nummer
                <input type="text" name="custom_id" value="<?= htmlspecialchars($nextNumber) ?>" placeholder="Bijvoorbeeld EXP-0001">
            </label>
            <label>Datum
                <input type="date" name="date" required value="<?= htmlspecialchars($report['date'] ?? date('Y-m-d')) ?>">
            </label>
            <label>Ontvanger selecteren
                <select id="recipientSelect" onchange="fillRecipient(this)">
                    <option value="">-- Selecteer bestaande ontvanger --</option>
                    <?php foreach ($recipients as $recipient): ?>
                        <option value='<?= json_encode($recipient, JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_TAG) ?>' <?= ($report['recipient'] ?? '') === ($recipient['name'] ?? '') ? 'selected' : '' ?>><?= htmlspecialchars($recipient['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Naam ontvanger
                <input type="text" name="recipient" id="recipientName" required value="<?= htmlspecialchars($report['recipient'] ?? '') ?>">
            </label>
            <label>Adres ontvanger
                <input type="text" name="address" id="recipientAddress" required value="<?= htmlspecialchars($report['address'] ?? '') ?>">
            </label>
            <label>IBAN
                <input type="text" name="iban" id="recipientIBAN" required value="<?= htmlspecialchars($report['iban'] ?? '') ?>">
            </label>
            <label>Bank
                <input type="text" name="bank_name" id="recipientBank" required value="<?= htmlspecialchars($report['bank_name'] ?? '') ?>">
            </label>
            <label>Categorie
                <select name="category_id">
                    <option value="">Geen categorie</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= (int)$category['id'] ?>" <?= isset($report['category_id']) && (int)$report['category_id'] === (int)$category['id'] ? 'selected' : '' ?>><?= htmlspecialchars($category['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <label>Omschrijving / Doel (Markdown ondersteund)
            <textarea name="description" id="descriptionInput" placeholder="Beschrijf het doel van deze kosten met Markdown."><?= htmlspecialchars($report['description'] ?? '') ?></textarea>
        </label>
        <div>
            <div style="display:flex;align-items:center;justify-content:space-between;">
                <h3 style="margin:0;">Markdown voorbeeld</h3>
                <small style="color:var(--color-muted);">Ondersteunt koppen (#), lijstjes (- of 1.), **vet**, _cursief_ en links.</small>
            </div>
            <div class="markdown-preview" id="descriptionPreview"><?= $descriptionPreview ?: '<em>Nog geen inhoud.</em>' ?></div>
        </div>
        <h3>Regels</h3>
        <div id="lines">
            <?php foreach ($lines as $line): ?>
                <div class="card" style="padding:16px;margin-bottom:16px;">
                    <input type="hidden" name="line_id[]" value="<?= htmlspecialchars($line['id'] ?? '') ?>">
                    <div class="grid-2">
                        <label>Omschrijving
                            <textarea name="description_line[]" placeholder="Omschrijving" required><?= htmlspecialchars($line['description'] ?? '') ?></textarea>
                        </label>
                        <label>Hoeveelheid
                            <input name="quantity[]" type="number" step="0.01" required value="<?= htmlspecialchars($line['quantity'] ?? ($line['kwh'] ?? '')) ?>">
                        </label>
                        <label>Eenheid
                            <select name="unit[]" required>
                                <option value="">Kies eenheid</option>
                                <?php foreach ($unitOptions as $unit): ?>
                                    <option value="<?= htmlspecialchars($unit) ?>" <?= (($line['unit'] ?? '') === $unit) ? 'selected' : '' ?>><?= htmlspecialchars($unit) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label>Prijs per eenheid
                            <input name="rate[]" type="number" step="0.0001" required value="<?= htmlspecialchars($line['rate'] ?? '') ?>">
                        </label>
                    </div>
                    <div style="display:flex;justify-content:flex-end;">
                        <button type="button" class="button" style="background:linear-gradient(135deg,#ef4444,#dc2626);" onclick="removeLine(this)">Regel verwijderen</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <button type="button" onclick="addLine()">+ Regel toevoegen</button>
        <div style="display:flex;gap:12px;justify-content:flex-end;">
            <button type="submit">Bewaren</button>
        </div>
    </form>
</section>

<?php if ($editMode): ?>
    <?php
    $attStmt = $db->prepare('SELECT * FROM expense_attachments WHERE report_id = ? ORDER BY uploaded_at DESC');
    $attStmt->execute([$id]);
    $attachments = $attStmt->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <section class="card">
        <h2>Bijlagen</h2>
        <?php if (empty($attachments)): ?>
            <p class="notice">Nog geen bijlagen toegevoegd.</p>
        <?php else: ?>
            <ul style="list-style:none;padding:0;margin:0;">
                <?php foreach ($attachments as $attachment): ?>
                    <li style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--color-border);">
                        <div>
                            <strong><?= htmlspecialchars($attachment['original_name']) ?></strong>
                            <div style="font-size:0.85rem;color:var(--color-muted);">Geüpload op <?= htmlspecialchars($attachment['uploaded_at']) ?> • <?= number_format(((int)$attachment['size_bytes']) / 1024, 1, ',', '.') ?> KB</div>
                        </div>
                        <div style="display:flex;gap:12px;align-items:center;">
                            <a href="file.php?id=<?= (int)$attachment['id'] ?>" target="_blank" rel="noopener">Bekijken</a>
                            <form action="delete-attachment.php" method="post" onsubmit="return confirm('Bijlage verwijderen?');">
                                <input type="hidden" name="id" value="<?= (int)$attachment['id'] ?>">
                                <input type="hidden" name="redirect" value="form.php?id=<?= (int)$id ?>">
                                <button type="submit" style="background:linear-gradient(135deg,#ef4444,#dc2626);">Verwijderen</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        <form action="upload-attachment.php" method="post" enctype="multipart/form-data" style="margin-top:20px;">
            <input type="hidden" name="report_id" value="<?= (int)$id ?>">
            <input type="hidden" name="redirect" value="form.php?id=<?= (int)$id ?>">
            <label>Bestanden uploaden
                <input type="file" name="files[]" multiple accept=".pdf,.csv,.xlsx,.xls,image/*" required>
            </label>
            <button type="submit">Uploaden</button>
        </form>
    </section>
<?php endif; ?>

<script>
function fillRecipient(select) {
    if (!select.value) return;
    try {
        const data = JSON.parse(select.value);
        document.getElementById('recipientName').value = data.name || '';
        document.getElementById('recipientAddress').value = data.address || '';
        document.getElementById('recipientIBAN').value = data.iban || '';
        document.getElementById('recipientBank').value = data.bank_name || '';
    } catch (err) {
        console.error('Kon ontvanger niet laden', err);
    }
}

function addLine() {
    const container = document.getElementById('lines');
    const div = document.createElement('div');
    div.className = 'card';
    div.style.padding = '16px';
    div.style.marginBottom = '16px';
    const units = <?= json_encode($unitOptions, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP) ?>;
    const unitOptions = ['<option value="">Kies eenheid</option>'];
    units.forEach(u => unitOptions.push(`<option value="${u}">${u}</option>`));
    div.innerHTML = `
        <input type="hidden" name="line_id[]" value="">
        <div class="grid-2">
            <label>Omschrijving
                <textarea name="description_line[]" placeholder="Omschrijving" required></textarea>
            </label>
            <label>Hoeveelheid
                <input name="quantity[]" type="number" step="0.01" required>
            </label>
            <label>Eenheid
                <select name="unit[]" required>
                    ${unitOptions.join('')}
                </select>
            </label>
            <label>Prijs per eenheid
                <input name="rate[]" type="number" step="0.0001" required>
            </label>
        </div>
        <div style="display:flex;justify-content:flex-end;">
            <button type="button" class="button" style="background:linear-gradient(135deg,#ef4444,#dc2626);" onclick="removeLine(this)">Regel verwijderen</button>
        </div>
    `;
    container.appendChild(div);
}

function removeLine(button) {
    const card = button.closest('.card');
    if (card) {
        card.remove();
    }
}

function renderMarkdownPreview(text) {
    let html = text;
    html = html.replace(/\r\n/g, '\n');
    html = html.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');
    html = html.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
    html = html.replace(/_(.+?)_/g, '<em>$1</em>');
    html = html.replace(/\[(.+?)\]\((https?:[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    const blocks = html.split(/\n{2,}/).map(block => {
        if (/^#{1,6}\s+/.test(block)) {
            const match = block.match(/^(#{1,6})\s+(.+)/);
            const level = match[1].length;
            return `<h${level}>${match[2]}</h${level}>`;
        }
        if (/^(\s*[-*+]\s+)/.test(block)) {
            const items = block.split('\n').map(line => line.replace(/^\s*[-*+]\s+/, '')).map(item => `<li>${item}</li>`).join('');
            return `<ul>${items}</ul>`;
        }
        if (/^(\s*\d+\.\s+)/.test(block)) {
            const items = block.split('\n').map(line => line.replace(/^\s*\d+\.\s+/, '')).map(item => `<li>${item}</li>`).join('');
            return `<ol>${items}</ol>`;
        }
        return `<p>${block.replace(/\n/g, '<br>')}</p>`;
    });
    return blocks.join('');
}

const descriptionInput = document.getElementById('descriptionInput');
const descriptionPreviewEl = document.getElementById('descriptionPreview');
if (descriptionInput && descriptionPreviewEl) {
    descriptionInput.addEventListener('input', () => {
        const rendered = renderMarkdownPreview(descriptionInput.value);
        descriptionPreviewEl.innerHTML = rendered || '<em>Nog geen inhoud.</em>';
    });
}
</script>
<?php
renderPageEnd();
