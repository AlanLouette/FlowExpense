<?php
require_once __DIR__ . '/bootstrap.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);
require_once __DIR__ . '/layout.php';

$orgId = (int)$currentOrganization['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_id'])) {
        $deleteId = (int)$_POST['delete_id'];
        $stmt = $db->prepare('DELETE FROM units WHERE id = ? AND organization_id = ?');
        $stmt->execute([$deleteId, $orgId]);
        header('Location: units.php');
        exit;
    }

    $id = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $name = trim($_POST['name'] ?? '');

    if ($name === '') {
        http_response_code(400);
        exit('Naam is verplicht.');
    }

    if ($id) {
        $stmt = $db->prepare('UPDATE units SET name = ? WHERE id = ? AND organization_id = ?');
        $stmt->execute([$name, $id, $orgId]);
    } else {
        $stmt = $db->prepare('INSERT OR IGNORE INTO units (organization_id, name) VALUES (?, ?)');
        $stmt->execute([$orgId, $name]);
    }

    header('Location: units.php');
    exit;
}

$editUnit = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $db->prepare('SELECT * FROM units WHERE id = ? AND organization_id = ?');
    $stmt->execute([$editId, $orgId]);
    $editUnit = $stmt->fetch(PDO::FETCH_ASSOC);
}

$stmt = $db->prepare('SELECT * FROM units WHERE organization_id = ? ORDER BY name ASC');
$stmt->execute([$orgId]);
$units = $stmt->fetchAll(PDO::FETCH_ASSOC);

renderPageStart('Eenheden', 'units');
?>
<section class="card">
    <h2><?= $editUnit ? 'Eenheid bijwerken' : 'Nieuwe eenheid' ?></h2>
    <form method="post">
        <label>Naam
            <input type="text" name="name" required value="<?= htmlspecialchars($editUnit['name'] ?? '') ?>">
        </label>
        <?php if ($editUnit): ?>
            <input type="hidden" name="id" value="<?= (int)$editUnit['id'] ?>">
        <?php endif; ?>
        <div style="display:flex;gap:12px;justify-content:flex-end;">
            <button type="submit"><?= $editUnit ? 'Bijwerken' : 'Toevoegen' ?></button>
            <?php if ($editUnit): ?>
                <a class="button" href="units.php" style="display:inline-flex;align-items:center;background:linear-gradient(135deg,#9ca3af,#6b7280);padding:10px 18px;">Annuleren</a>
            <?php endif; ?>
        </div>
    </form>
</section>

<section class="card">
    <h2>Beschikbare eenheden</h2>
    <?php if (empty($units)): ?>
        <p class="notice">Er zijn nog geen eenheden gedefinieerd.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Naam</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($units as $unit): ?>
                <tr>
                    <td><?= htmlspecialchars($unit['name']) ?></td>
                    <td class="table-actions">
                        <a href="units.php?edit=<?= (int)$unit['id'] ?>">Bewerken</a>
                        <form method="post" style="display:inline;" onsubmit="return confirm('Eenheid verwijderen?');">
                            <input type="hidden" name="delete_id" value="<?= (int)$unit['id'] ?>">
                            <button type="submit" style="background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;padding:6px 12px;border-radius:8px;border:none;cursor:pointer;">Verwijderen</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php
renderPageEnd();
