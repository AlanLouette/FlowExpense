<?php
require_once __DIR__ . '/bootstrap.php';

if ($currentUser) {
    header('Location: index.php');
    exit;
}

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $db->prepare('SELECT * FROM users WHERE email = ? AND active = 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = (int)$user['id'];
        $orgs = fetchUserOrganizations($db, (int)$user['id']);
        if (!empty($orgs)) {
            $_SESSION['organization_id'] = (int)$orgs[0]['id'];
        }
        $redirect = $_GET['redirect'] ?? 'index.php';
        header('Location: ' . $redirect);
        exit;
    }

    $error = 'Ongeldige gebruikersnaam of wachtwoord.';
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inloggen · FlowExpense</title>
    <link rel="stylesheet" href="style.php">
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .auth-card {
            width: 100%;
            max-width: 420px;
            padding: 36px;
            border-radius: 18px;
            background: var(--color-surface);
            box-shadow: var(--shadow-md);
        }
        .auth-card h1 {
            margin-top: 0;
            margin-bottom: 8px;
        }
        .auth-card p {
            margin-top: 0;
            color: var(--color-muted);
        }
        .error {
            margin-bottom: 18px;
            padding: 12px;
            border-radius: var(--radius-sm);
            background: rgba(239, 68, 68, 0.12);
            color: #b91c1c;
        }
        .auth-card form {
            box-shadow: none;
            padding: 0;
            background: transparent;
            margin-bottom: 0;
        }
        .auth-card label {
            color: #111827;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="sidebar-header" style="margin-bottom: 24px;">
            <div class="logo-circle"></div>
            <span class="brand">FlowExpense</span>
        </div>
        <h1>Welkom terug</h1>
        <p>Log in met je bedrijfsaccount om je onkostennota's te beheren.</p>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post" autocomplete="on">
            <label>E-mailadres
                <input type="email" name="email" required autofocus>
            </label>
            <label>Wachtwoord
                <input type="password" name="password" required>
            </label>
            <button type="submit">Inloggen</button>
        </form>
    </div>
</body>
</html>
