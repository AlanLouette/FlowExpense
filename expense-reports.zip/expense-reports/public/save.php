<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/lib/expenses.php';
requireLogin();
enforceOrganizationAccess($currentOrganization ?? null);

function parseDecimal(string $value): float
{
    $normalized = str_replace([' ', ','], ['', '.'], trim($value));
    if ($normalized === '' || !is_numeric($normalized)) {
        return 0.0;
    }
    return (float)$normalized;
}

$orgId = (int)$currentOrganization['id'];
$isAdmin = $currentUser && (int)$currentUser['is_admin'] === 1;

$id = isset($_POST['id']) ? (int)$_POST['id'] : null;
$customId = trim($_POST['custom_id'] ?? '');
$recipient = trim($_POST['recipient'] ?? '');
$address = trim($_POST['address'] ?? '');
$iban = trim($_POST['iban'] ?? '');
$bankName = trim($_POST['bank_name'] ?? '');
$date = trim($_POST['date'] ?? '');
$description = trim($_POST['description'] ?? '');
$categoryId = $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;

$lineDescriptions = $_POST['description_line'] ?? [];
$lineQuantities = $_POST['quantity'] ?? [];
$lineUnits = $_POST['unit'] ?? [];
$lineRates = $_POST['rate'] ?? [];

if ($recipient === '' || $address === '' || $iban === '' || $bankName === '' || $date === '') {
    http_response_code(400);
    exit('Verplichte velden ontbreken.');
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    http_response_code(400);
    exit('Ongeldige datum opgegeven.');
}

try {
    $db->beginTransaction();

    $existingReport = null;
    if ($id) {
        $stmt = $db->prepare('SELECT * FROM expense_reports WHERE id = ? AND organization_id = ?');
        $stmt->execute([$id, $orgId]);
        $existingReport = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$existingReport) {
            throw new RuntimeException('Onkostennota niet gevonden.');
        }
        if (!$isAdmin && (int)$existingReport['user_id'] !== (int)$currentUser['id']) {
            throw new RuntimeException('Geen toestemming om deze onkostennota te bewerken.');
        }
    }

    $lineData = [];
    $max = max(count($lineDescriptions), count($lineQuantities), count($lineUnits), count($lineRates));
    for ($i = 0; $i < $max; $i++) {
        $descLine = trim($lineDescriptions[$i] ?? '');
        $qty = parseDecimal((string)($lineQuantities[$i] ?? '0'));
        $unit = trim($lineUnits[$i] ?? '');
        $rate = parseDecimal((string)($lineRates[$i] ?? '0'));

        if ($descLine === '' && $qty === 0.0 && $rate === 0.0) {
            continue;
        }

        if ($descLine === '') {
            throw new RuntimeException('Elke regel heeft een omschrijving nodig.');
        }

        $lineData[] = [
            'description' => $descLine,
            'quantity' => $qty,
            'unit' => $unit,
            'rate' => $rate
        ];
    }

    if (empty($lineData)) {
        throw new RuntimeException('Voeg minstens één regel toe.');
    }

    $total = 0.0;
    foreach ($lineData as $line) {
        $total += $line['quantity'] * $line['rate'];
    }

    if ($id) {
        $finalCustomId = $customId !== '' ? $customId : ($existingReport['custom_id'] ?? '');
        if ($finalCustomId === '') {
            $finalCustomId = generate_custom_id($db, $orgId);
        } else {
            ensure_unique_custom_id($db, $orgId, $finalCustomId, $id);
        }

        $update = $db->prepare('UPDATE expense_reports SET custom_id = ?, recipient = ?, address = ?, description = ?, iban = ?, bank_name = ?, date = ?, total = ?, category_id = ? WHERE id = ?');
        $update->execute([
            $finalCustomId,
            $recipient,
            $address,
            $description,
            $iban,
            $bankName,
            $date,
            $total,
            $categoryId,
            $id
        ]);

        $db->prepare('DELETE FROM expense_lines WHERE report_id = ?')->execute([$id]);
        $insertLine = $db->prepare('INSERT INTO expense_lines (report_id, description, quantity, unit, rate) VALUES (?, ?, ?, ?, ?)');
        foreach ($lineData as $line) {
            $insertLine->execute([$id, $line['description'], $line['quantity'], $line['unit'], $line['rate']]);
        }
        $newId = $id;
    } else {
        if ($customId === '') {
            $customId = generate_custom_id($db, $orgId);
        } else {
            ensure_unique_custom_id($db, $orgId, $customId, null);
        }

        $insert = $db->prepare('INSERT INTO expense_reports (organization_id, user_id, custom_id, recipient, address, description, iban, bank_name, date, total, status, category_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $insert->execute([
            $orgId,
            (int)$currentUser['id'],
            $customId,
            $recipient,
            $address,
            $description,
            $iban,
            $bankName,
            $date,
            $total,
            'Open',
            $categoryId
        ]);
        $newId = (int)$db->lastInsertId();

        $insertLine = $db->prepare('INSERT INTO expense_lines (report_id, description, quantity, unit, rate) VALUES (?, ?, ?, ?, ?)');
        foreach ($lineData as $line) {
            $insertLine->execute([$newId, $line['description'], $line['quantity'], $line['unit'], $line['rate']]);
        }
    }

    $db->commit();
    header('Location: form.php?id=' . $newId);
    exit;
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    http_response_code(400);
    echo 'Opslaan mislukt: ' . htmlspecialchars($e->getMessage());
    exit;
}
