<?php
require_once __DIR__ . '/bootstrap.php';

enforceOrganizationAccess($currentOrganization ?? null);

function nav_link(string $href, string $label, string $page, string $currentPage): string
{
    $active = $page === $currentPage ? 'active' : '';
    return sprintf('<a class="nav-link %s" href="%s">%s</a>', $active, htmlspecialchars($href), htmlspecialchars($label));
}

function renderPageStart(string $title, string $currentPage = ''): void
{
    global $currentUser, $availableOrganizations, $currentOrganization;
    ?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> · Expense</title>
    <link rel="stylesheet" href="style.php">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
<div class="app-shell">
    <aside class="app-sidebar">
        <div class="sidebar-header">
            <div class="logo-circle"></div>
            <span class="brand">FlowExpense</span>
        </div>
        <nav class="sidebar-nav">
            <?= nav_link('index.php', 'Dashboard', 'index', $currentPage) ?>
            <?= nav_link('form.php', 'Nieuwe onkostennota', 'form', $currentPage) ?>
            <?= nav_link('recipients.php', 'Ontvangers', 'recipients', $currentPage) ?>
            <?= nav_link('categories.php', 'Categorieën', 'categories', $currentPage) ?>
            <?= nav_link('units.php', 'Eenheden', 'units', $currentPage) ?>
            <?= nav_link('settings.php', 'Instellingen', 'settings', $currentPage) ?>
            <?php if ($currentUser && (int)$currentUser['is_admin'] === 1): ?>
                <?= nav_link('users.php', 'Gebruikers', 'users', $currentPage) ?>
                <?= nav_link('organizations.php', 'Organisaties', 'organizations', $currentPage) ?>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="user-meta">
                <span class="user-name"><?= htmlspecialchars($currentUser['name'] ?? '') ?></span>
                <span class="user-email"><?= htmlspecialchars($currentUser['email'] ?? '') ?></span>
            </div>
            <a class="logout-link" href="logout.php">Afmelden</a>
        </div>
    </aside>
    <div class="app-content">
        <header class="app-topbar">
            <div class="topbar-left">
                <h1><?= htmlspecialchars($title) ?></h1>
                <?php if (!empty($currentOrganization['legal_name'])): ?>
                    <span class="org-subtitle"><?= htmlspecialchars($currentOrganization['legal_name']) ?></span>
                <?php endif; ?>
            </div>
            <div class="topbar-right">
                <?php if (!empty($availableOrganizations)): ?>
                    <form method="post" action="switch-organization.php" class="org-switcher">
                        <label for="organization_id">Organisatie</label>
                        <select name="organization_id" id="organization_id" onchange="this.form.submit()">
                            <?php foreach ($availableOrganizations as $org): ?>
                                <option value="<?= (int)$org['id'] ?>" <?= ((int)$org['id'] === (int)$currentOrganization['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($org['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                <?php endif; ?>
            </div>
        </header>
        <main class="app-main">
    <?php
}

function renderPageEnd(): void
{
    ?>
        </main>
    </div>
</div>
</body>
</html>
    <?php
}
